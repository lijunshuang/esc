<template>
    <div>
        <input type="file" ref="file" hidden @change="changeUp" />
        <!-- <button>上传照片</button> -->
        <h2>请上传汽车图片</h2>
        <div class="upbox" ref="upbox">
            <Picgrid v-for="item in ImgFiles" :key="item.id" :file="item"></Picgrid>
            <div class="btn" @click="choosePic"></div>
        </div>
    </div>
</template>

<script>
import Picgrid from "./Picgrid";
    export default {
        data() {
            return {
                ImgFiles : [],
            }
        },
        mounted(){
            this.$refs.upbox.addEventListener("dragenter",e => e.preventDefault(), false)
            this.$refs.upbox.addEventListener("dragover",function(e) {
                e.preventDefault();
                $(".upbox").addClass("on");
            },false);
            this.$refs.upbox.addEventListener("dragleave",function(e) {
                e.preventDefault();
                $(".upbox").removeClass("on");
            },false);
            var self = this; //拖拽释放是 异步事件，所以要备份
            this.$refs.upbox.addEventListener("drop",function(e) {
                e.preventDefault();
                $(".upbox").removeClass("on");
                console.log(e.dataTransfer.files);
                self.ImgFiles.push(...e.dataTransfer.files);
            },false)
        },
        methods: {
            changeUp(){
                var ImgFiles = this.$refs.file.files;
                for (let i = 0; i < ImgFiles.length; i++) {
                    this.ImgFiles.push(ImgFiles[i]);
                }
            },
            choosePic() {
                //模拟触发事件
                var evt = document.createEvent("MouseEvents");
                evt.initMouseEvent("click",false,false);
                this.$refs.file.dispatchEvent(evt);
            }
        },
        components : {
            Picgrid
        }
    }
</script>

<style scoped lang="less">
h2{
    margin-top:10px;
    em{font-style: normal;font-size: 14px;color:#ccc;margin-left:10px;font-weight: normal}
}
.upbox{
    margin-top:20px;padding:10px 0px 10px 10px;min-height:120px;border:1px dashed #ddd;transition:all .4s ease 0s;display:flex;flex-wrap:wrap;;
    &.on{border:1px dashed #ccc;background:#eee}
    &::after{content: '';display:block;clear: both;}
    .btn{
        width:140px;height: 180px;border:1px dashed #ddd;position: relative;transition:all .4s ease 0s;
        &::after{
            content: "+";
            font-size: 80px;
            font-weight: bold;
            text-align: center;
            position: absolute;
            width: 100%;
            height: 100%;
            line-height: 150px;
            color: #ddd;
        }
        &:hover{background:#eee;}
    }
}
</style>